# SkyCast – Real-Time Weather Dashboard

A modern, visually stunning, fully responsive Real-Time Weather Dashboard built using HTML5, CSS3, Bootstrap 5, and Vanilla JavaScript (ES6+). SkyCast connects directly with the public Open-Meteo REST APIs to deliver live weather conditions, hourly forecasts, and 5-day forecasts with zero API key requirements.

---

## Table of Contents

- [Overview](#overview)
- [Key Features](#key-features)
- [Design & UI/UX Highlights](#design--uiux-highlights)
- [Technologies Used](#technologies-used)
- [API Integration & Documentation](#api-integration--documentation)
- [Project Folder Structure](#project-folder-structure)
- [Installation and Setup](#installation-and-setup)
- [Running with VS Code Live Server](#running-with-vs-code-live-server)
- [Screenshots](#screenshots)
- [Asynchronous JavaScript & Concepts Learned](#asynchronous-javascript--concepts-learned)
- [License](#license)

---

## Overview

SkyCast provides users with instantaneous, accurate meteorological data for any city worldwide. Built with modern ES6+ modular JavaScript, it demonstrates asynchronous data fetching, dynamic DOM manipulation, and responsive glassmorphic UI design.

---

## Key Features

- **City Search & Geocoding**: Search any city worldwide with instant geocoding resolution via the Open-Meteo Geocoding API.
- **Popular Cities Quick Access**: One-click weather forecast cards for major global cities (New York, Tokyo, Paris, Mumbai, Sydney).
- **Real-Time Weather Metrics**:
  - Current temperature in Celsius (°C).
  - Apparent ("Feels like") temperature.
  - Weather condition summary and animated dynamic icons.
  - Relative humidity percentage with a visual fill bar.
  - Wind speed (km/h) and compass wind direction with dynamic rotating arrow indicator.
  - Atmospheric sea-level pressure (hPa).
  - Cloud cover percentage with gauge bar.
  - Current precipitation volume (mm).
  - Day / Night status indicator.
  - Daily High and Low temperature range.
- **24-Hour Hourly Forecast**:
  - Horizontally scrollable forecast stream for the upcoming 24 hours.
  - Shows hourly temperature, WMO weather condition icons, and precipitation probability percentages.
  - Highlighted current hour.
- **5-Day Daily Weather Forecast**:
  - 5-day forecast cards showing date and day names.
  - Maximum and minimum temperatures.
  - WMO weather conditions and weather icons.
  - Exact sunrise and sunset times formatted for the city's local timezone.
- **Robust Error Handling**:
  - Validates empty submissions.
  - Handles non-existent or misspelled cities with clear, friendly feedback.
  - Catches network drops and API server outages.
  - Prevents dashboard from remaining stuck in loading states using `try...catch...finally`.
- **Responsive Layout**:
  - Mobile-first, fully responsive on mobile devices, tablets, laptops, and desktop screens.

---

## Design & UI/UX Highlights

- **Glassmorphism Aesthetic**: Modern frosted-glass panels with `backdrop-filter: blur(18px)`, translucent surfaces, and subtle glow borders.
- **Adaptive Atmosphere Themes**: The background gradient automatically adapts to the city's current weather condition (Day Clear, Night Clear, Cloudy, Rain, Thunderstorm, Snow, Fog).
- **Micro-Interactions**: Floating weather icon animations, rotating compass direction needles, and spinning refresh actions.
- **Accessible & Semantic**: High-contrast typography powered by Plus Jakarta Sans and semantic HTML5 landmarks.

---

## Technologies Used

- **HTML5**: Semantic document structure.
- **CSS3**: Custom CSS variables, flexbox, CSS grid, glassmorphism, keyframe animations, and custom scrollbars.
- **Bootstrap 5.3.3**: Responsive grid layout and utility classes.
- **Bootstrap Icons 1.11.3**: Crisp vector weather and interface iconography.
- **Vanilla JavaScript (ES6+)**:
  - ES Modules (`import` / `export`)
  - Asynchronous functions with `async` and `await`
  - JavaScript `Fetch API`
  - `URLSearchParams` for safe dynamic query string generation
  - `Intl.DateTimeFormat` for timezone-accurate date and time rendering
  - Array methods (`map`, `filter`, `findIndex`, `slice`)

---

## API Integration & Documentation

SkyCast uses public REST endpoints from [Open-Meteo](https://open-meteo.com/en/docs), which require no API keys or subscription.

### 1. Geocoding API (City Search)
- **Endpoint**: `https://geocoding-api.open-meteo.com/v1/search`
- **Parameters**:
  - `name`: City name query string
  - `count`: Maximum results (5)
  - `language`: `en`
  - `format`: `json`
- **Output Extracted**: Name, administrative region, country, latitude, longitude, and timezone.

### 2. Weather Forecast API
- **Endpoint**: `https://api.open-meteo.com/v1/forecast`
- **Parameters**:
  - `latitude`, `longitude`: Geographic coordinates
  - `current`: `temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m`
  - `hourly`: `temperature_2m,precipitation_probability,weather_code`
  - `daily`: `weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset`
  - `timezone`: `auto`
  - `forecast_days`: `5`

---

## Project Folder Structure

```text
skycast-weather-dashboard/
│
├── index.html                  # Main dashboard HTML structure
│
├── css/
│   └── style.css               # Glassmorphism styling, animations, themes, and responsiveness
│
├── js/
│   ├── config.js               # API endpoints, default cities, and WMO weather code dictionary
│   ├── weather.js              # Fetch requests, async processing, and data parsing
│   └── app.js                  # DOM manipulation, UI controllers, and event listeners
│
├── assets/
│   ├── images/
│   │   ├── skycast-logo.svg    # SkyCast application brand icon
│   │   └── skycast-banner.svg  # Dashboard visual banner
│   └── icons/
│       ├── sun.svg             # Vector sun icon
│       ├── moon.svg            # Vector moon icon
│       ├── cloud.svg           # Vector cloud icon
│       ├── rain.svg            # Vector rain icon
│       ├── snow.svg            # Vector snow icon
│       └── thunder.svg         # Vector thunder icon
│
└── README.md                   # Comprehensive project documentation
```

---

## Installation and Setup

Since SkyCast is built exclusively with standard web technologies and ES modules, no build steps or package managers (`npm`/`yarn`) are required.

1. Clone or download the repository to your local computer:
   ```bash
   git clone <repository-url>
   cd "real-time Weather Dashboard"
   ```

2. Because ES modules (`type="module"`) require a local HTTP server to satisfy browser CORS security policies, serve the project using any local web server.

---

## Running with VS Code Live Server

1. Open Visual Studio Code.
2. Click **File > Open Folder...** and select the `real-time Weather Dashboard` directory.
3. Install the **Live Server** extension by Ritwick Dey from the VS Code Marketplace if not already installed.
4. Right-click `index.html` in the file explorer and select **Open with Live Server** (or click the **Go Live** button in the bottom status bar).
5. The application will automatically open in your default browser at `http://127.0.0.1:5500/index.html`.

---

## Screenshots

| Desktop Dashboard View | Mobile Responsive View |
| :---: | :---: |
| ![Desktop Dashboard](assets/images/skycast-banner.svg) | ![Mobile View](assets/images/skycast-logo.svg) |

---

## Asynchronous JavaScript & Concepts Learned

1. **Fetch API & Promises**: Initiating non-blocking HTTP requests to RESTful endpoints and converting raw responses into JSON payloads.
2. **async / await Pattern**: Writing clean, readable asynchronous code without nested callback pyramids.
3. **HTTP Response Validation**: Explicitly checking `response.ok` before consuming payloads to catch 4xx and 5xx HTTP response codes.
4. **URLSearchParams**: Constructing dynamic URL query strings safely without manual string concatenation.
5. **Robust Error Handling**: Utilizing `try / catch / finally` blocks to guarantee UI loaders are dismissed and meaningful messages are displayed.
6. **ES Modules Architecture**: Separating concerns across modular files (`config.js`, `weather.js`, and `app.js`).
7. **Timezone Handling**: Parsing and localizing dates and times with `Intl.DateTimeFormat`.
8. **Modern DOM Manipulation**: Dynamically updating templates, styles, and progress gauges based on live API responses.

---

## License

This project is licensed under the MIT License - open for educational and non-commercial usage. Weather data provided by [Open-Meteo](https://open-meteo.com/).
