let elements = {};
let currentCityState = { ...window.DEFAULT_CITY };
let isLoading = false;

function initElements() {
  elements = {
    searchForm: document.getElementById("search-form"),
    searchInput: document.getElementById("search-input"),
    searchBtn: document.getElementById("search-btn"),
    refreshBtn: document.getElementById("refresh-btn"),
    errorAlert: document.getElementById("error-alert"),
    errorMessage: document.getElementById("error-message"),
    errorDismiss: document.getElementById("error-dismiss"),
    loadingOverlay: document.getElementById("loading-overlay"),
    weatherContent: document.getElementById("weather-content"),
    popularCitiesContainer: document.getElementById("popular-cities-container"),
    cityName: document.getElementById("city-name"),
    cityRegion: document.getElementById("city-region"),
    currentDateTime: document.getElementById("current-date-time"),
    currentTemp: document.getElementById("current-temp"),
    feelsLikeTemp: document.getElementById("feels-like-temp"),
    weatherCondition: document.getElementById("weather-condition"),
    weatherIcon: document.getElementById("weather-icon"),
    tempHighLow: document.getElementById("temp-high-low"),
    dayNightBadge: document.getElementById("day-night-badge"),
    humidityValue: document.getElementById("humidity-value"),
    humidityProgress: document.getElementById("humidity-progress"),
    windSpeedValue: document.getElementById("wind-speed-value"),
    windDirectionText: document.getElementById("wind-direction-text"),
    windArrow: document.getElementById("wind-arrow"),
    pressureValue: document.getElementById("pressure-value"),
    cloudCoverValue: document.getElementById("cloud-cover-value"),
    cloudCoverProgress: document.getElementById("cloud-cover-progress"),
    precipitationValue: document.getElementById("precipitation-value"),
    hourlyForecastContainer: document.getElementById("hourly-forecast-container"),
    dailyForecastContainer: document.getElementById("daily-forecast-container"),
    lastUpdatedText: document.getElementById("last-updated-text"),
    appContainer: document.getElementById("skycast-app")
  };
}

function formatCityDateTime(timezone) {
  try {
    const now = new Date();
    const options = {
      weekday: "long",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    };
    if (timezone && timezone !== "auto") {
      options.timeZone = timezone;
    }
    return new Intl.DateTimeFormat("en-US", options).format(now);
  } catch {
    return new Date().toLocaleString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });
  }
}

function formatHourlyTime(isoString, index, timezone) {
  if (index === 0) return "Now";
  try {
    if (isoString.includes("T")) {
      const timePart = isoString.split("T")[1];
      const hour = parseInt(timePart.split(":")[0], 10);
      const period = hour >= 12 ? "PM" : "AM";
      const formattedHour = hour % 12 === 0 ? 12 : hour % 12;
      return `${formattedHour} ${period}`;
    }
    const date = new Date(isoString);
    const hours = date.getHours();
    const period = hours >= 12 ? "PM" : "AM";
    const formattedHour = hours % 12 === 0 ? 12 : hours % 12;
    return `${formattedHour} ${period}`;
  } catch {
    return "--";
  }
}

function formatDailyDate(isoDateString, index, timezone) {
  if (index === 0) return "Today";
  if (index === 1) return "Tomorrow";
  try {
    const parts = isoDateString.split("-");
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    const date = new Date(year, month, day);
    return new Intl.DateTimeFormat("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric"
    }).format(date);
  } catch {
    const parts = isoDateString.split("-");
    return `${parts[1]}/${parts[2]}`;
  }
}

function formatSunTime(isoString, timezone) {
  if (!isoString) return "--:--";
  try {
    if (isoString.includes("T")) {
      const timePart = isoString.split("T")[1];
      const [h, m] = timePart.split(":");
      const hour = parseInt(h, 10);
      const minutes = m.padStart(2, "0");
      const period = hour >= 12 ? "PM" : "AM";
      const formattedHour = hour % 12 === 0 ? 12 : hour % 12;
      return `${formattedHour}:${minutes} ${period}`;
    }
    const date = new Date(isoString);
    const hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const period = hours >= 12 ? "PM" : "AM";
    const formattedHour = hours % 12 === 0 ? 12 : hours % 12;
    return `${formattedHour}:${minutes} ${period}`;
  } catch {
    return "--:--";
  }
}

function showLoading() {
  isLoading = true;
  if (elements.loadingOverlay) {
    elements.loadingOverlay.classList.remove("d-none");
  }
  if (elements.searchBtn) {
    elements.searchBtn.disabled = true;
  }
  if (elements.refreshBtn) {
    elements.refreshBtn.disabled = true;
    elements.refreshBtn.classList.add("spinning");
  }
  hideError();
}

function hideLoading() {
  isLoading = false;
  if (elements.loadingOverlay) {
    elements.loadingOverlay.classList.add("d-none");
  }
  if (elements.searchBtn) {
    elements.searchBtn.disabled = false;
  }
  if (elements.refreshBtn) {
    elements.refreshBtn.disabled = false;
    elements.refreshBtn.classList.remove("spinning");
  }
}

function showError(message) {
  if (elements.errorMessage && elements.errorAlert) {
    elements.errorMessage.textContent = message || "An unexpected error occurred. Please try again.";
    elements.errorAlert.classList.remove("d-none");
    elements.errorAlert.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

function hideError() {
  if (elements.errorAlert) {
    elements.errorAlert.classList.add("d-none");
  }
}

function updateThemeBackground(weatherCode, isDay) {
  if (!elements.appContainer) return;

  elements.appContainer.classList.remove(
    "theme-clear-day",
    "theme-clear-night",
    "theme-cloudy-day",
    "theme-cloudy-night",
    "theme-rain",
    "theme-thunder",
    "theme-snow",
    "theme-fog"
  );

  const code = Number(weatherCode);

  if (code >= 95) {
    elements.appContainer.classList.add("theme-thunder");
  } else if ((code >= 71 && code <= 77) || code === 85 || code === 86) {
    elements.appContainer.classList.add("theme-snow");
  } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
    elements.appContainer.classList.add("theme-rain");
  } else if (code === 45 || code === 48) {
    elements.appContainer.classList.add("theme-fog");
  } else if (code === 2 || code === 3) {
    elements.appContainer.classList.add(isDay ? "theme-cloudy-day" : "theme-cloudy-night");
  } else {
    elements.appContainer.classList.add(isDay ? "theme-clear-day" : "theme-clear-night");
  }
}

function displayCurrentWeather(data, city) {
  if (!data || !data.current) return;

  const current = data.current;
  const daily = data.daily;

  if (elements.cityName) {
    elements.cityName.textContent = city.name;
  }

  if (elements.cityRegion) {
    const locationParts = [city.admin1, city.country].filter(Boolean);
    elements.cityRegion.textContent = locationParts.join(", ") || city.country || "Earth";
  }

  if (elements.currentDateTime) {
    elements.currentDateTime.textContent = formatCityDateTime(data.timezone);
  }

  const roundedTemp = Math.round(current.temperature_2m);
  if (elements.currentTemp) {
    elements.currentTemp.textContent = `${roundedTemp}°`;
  }

  const feelsLike = Math.round(current.apparent_temperature);
  if (elements.feelsLikeTemp) {
    elements.feelsLikeTemp.textContent = `Feels like ${feelsLike}°C`;
  }

  const isDay = current.is_day === 1;
  const description = window.getWeatherDescription(current.weather_code);
  const iconClass = window.getWeatherIcon(current.weather_code, isDay);
  const iconColor = window.getWeatherColor(current.weather_code);

  if (elements.weatherCondition) {
    elements.weatherCondition.textContent = description;
  }

  if (elements.weatherIcon) {
    elements.weatherIcon.className = `bi ${iconClass} display-icon`;
    elements.weatherIcon.style.color = iconColor;
  }

  if (elements.tempHighLow && daily && daily.temperature_2m_max && daily.temperature_2m_min) {
    const maxTemp = Math.round(daily.temperature_2m_max[0]);
    const minTemp = Math.round(daily.temperature_2m_min[0]);
    elements.tempHighLow.innerHTML = `<i class="bi bi-arrow-up text-danger"></i> ${maxTemp}°C <span class="mx-1 opacity-50">/</span> <i class="bi bi-arrow-down text-info"></i> ${minTemp}°C`;
  }

  if (elements.dayNightBadge) {
    if (isDay) {
      elements.dayNightBadge.innerHTML = `<i class="bi bi-sun-fill text-warning me-1"></i> Daytime`;
      elements.dayNightBadge.className = "badge bg-warning bg-opacity-25 text-warning border border-warning border-opacity-50 px-3 py-2 rounded-pill";
    } else {
      elements.dayNightBadge.innerHTML = `<i class="bi bi-moon-stars-fill text-info me-1"></i> Nighttime`;
      elements.dayNightBadge.className = "badge bg-info bg-opacity-25 text-info border border-info border-opacity-50 px-3 py-2 rounded-pill";
    }
  }

  if (elements.humidityValue) {
    elements.humidityValue.textContent = `${current.relative_humidity_2m}%`;
  }
  if (elements.humidityProgress) {
    elements.humidityProgress.style.width = `${Math.min(100, Math.max(0, current.relative_humidity_2m))}%`;
  }

  const windSpeedKmh = Math.round(current.wind_speed_10m);
  if (elements.windSpeedValue) {
    elements.windSpeedValue.textContent = `${windSpeedKmh} km/h`;
  }

  const windDirCompass = window.getWindDirection(current.wind_direction_10m);
  if (elements.windDirectionText) {
    elements.windDirectionText.textContent = `${windDirCompass} (${Math.round(current.wind_direction_10m)}°)`;
  }

  if (elements.windArrow) {
    elements.windArrow.style.transform = `rotate(${current.wind_direction_10m}deg)`;
  }

  if (elements.pressureValue) {
    elements.pressureValue.textContent = `${Math.round(current.pressure_msl)} hPa`;
  }

  if (elements.cloudCoverValue) {
    elements.cloudCoverValue.textContent = `${current.cloud_cover}%`;
  }
  if (elements.cloudCoverProgress) {
    elements.cloudCoverProgress.style.width = `${Math.min(100, Math.max(0, current.cloud_cover))}%`;
  }

  if (elements.precipitationValue) {
    elements.precipitationValue.textContent = `${Number(current.precipitation).toFixed(1)} mm`;
  }

  updateThemeBackground(current.weather_code, isDay);
}

function displayHourlyForecast(data) {
  if (!elements.hourlyForecastContainer || !data || !data.hourly || !Array.isArray(data.hourly.time)) {
    return;
  }

  const times = data.hourly.time;
  const temps = data.hourly.temperature_2m;
  const probs = data.hourly.precipitation_probability || [];
  const codes = data.hourly.weather_code;
  const currentTimeIso = data.current?.time || "";

  let startIndex = 0;
  if (currentTimeIso) {
    const currentPrefix = currentTimeIso.slice(0, 13);
    const foundIdx = times.findIndex((t) => t.startsWith(currentPrefix));
    if (foundIdx !== -1) {
      startIndex = foundIdx;
    }
  }

  const forecastSlice = times.slice(startIndex, startIndex + 24);

  const cardsHtml = forecastSlice.map((isoTime, relIdx) => {
    const actualIdx = startIndex + relIdx;
    const timeLabel = formatHourlyTime(isoTime, relIdx, data.timezone);
    const temp = Math.round(temps[actualIdx] ?? 0);
    const prob = probs[actualIdx] !== undefined ? probs[actualIdx] : 0;
    const code = codes[actualIdx] ?? 0;

    let hourNumber = 12;
    if (isoTime.includes("T")) {
      hourNumber = parseInt(isoTime.split("T")[1].split(":")[0], 10) || 0;
    }
    const isDayHour = hourNumber >= 6 && hourNumber < 19;
    const iconClass = window.getWeatherIcon(code, isDayHour);
    const desc = window.getWeatherDescription(code);

    return `
      <div class="hourly-card text-center p-3 rounded-4 ${relIdx === 0 ? 'current-hour' : ''}">
        <span class="hourly-time text-light-50 small d-block mb-2">${timeLabel}</span>
        <div class="hourly-icon-wrap my-2">
          <i class="bi ${iconClass} fs-3" title="${desc}"></i>
        </div>
        <div class="hourly-temp fw-bold fs-5 mb-2">${temp}°</div>
        <div class="hourly-prob small ${prob > 20 ? 'text-cyan fw-semibold' : 'text-light-50'}">
          <i class="bi bi-droplet-fill me-1"></i>${prob}%
        </div>
      </div>
    `;
  }).join("");

  elements.hourlyForecastContainer.innerHTML = cardsHtml;
}

function displayDailyForecast(data) {
  if (!elements.dailyForecastContainer || !data || !data.daily || !Array.isArray(data.daily.time)) {
    return;
  }

  const daily = data.daily;
  const times = daily.time;
  const maxTemps = daily.temperature_2m_max || [];
  const minTemps = daily.temperature_2m_min || [];
  const codes = daily.weather_code || [];
  const sunrises = daily.sunrise || [];
  const sunsets = daily.sunset || [];

  const itemsHtml = times.slice(0, 5).map((isoDate, index) => {
    const dayLabel = formatDailyDate(isoDate, index, data.timezone);
    const maxTemp = Math.round(maxTemps[index] ?? 0);
    const minTemp = Math.round(minTemps[index] ?? 0);
    const code = codes[index] ?? 0;
    const iconClass = window.getWeatherIcon(code, true);
    const desc = window.getWeatherDescription(code);
    const sunriseTime = formatSunTime(sunrises[index], data.timezone);
    const sunsetTime = formatSunTime(sunsets[index], data.timezone);

    return `
      <div class="daily-item p-3 rounded-4 mb-2">
        <div class="row align-items-center g-2">
          <div class="col-4 col-md-3">
            <span class="fw-semibold d-block text-white">${dayLabel}</span>
            <span class="small text-light-50 text-truncate d-block">${desc}</span>
          </div>
          <div class="col-3 col-md-2 text-center">
            <i class="bi ${iconClass} fs-2 text-warning" title="${desc}"></i>
          </div>
          <div class="col-5 col-md-4 text-center">
            <div class="d-flex align-items-center justify-content-center gap-2">
              <span class="fw-bold text-white fs-6">${maxTemp}°</span>
              <div class="temp-bar-bg flex-grow-1 mx-1 d-none d-sm-block">
                <div class="temp-bar-fill"></div>
              </div>
              <span class="text-light-50 fs-6">${minTemp}°</span>
            </div>
          </div>
          <div class="col-12 col-md-3 text-md-end text-center pt-2 pt-md-0 border-top border-md-0 border-white-10">
            <div class="d-inline-flex align-items-center gap-3 small text-light-50">
              <span title="Sunrise"><i class="bi bi-sunrise text-warning me-1"></i>${sunriseTime}</span>
              <span title="Sunset"><i class="bi bi-sunset text-orange me-1"></i>${sunsetTime}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join("");

  elements.dailyForecastContainer.innerHTML = itemsHtml;
}

async function loadWeatherForCity(city) {
  showLoading();

  try {
    const weatherData = await window.fetchWeather(city.latitude, city.longitude, city.timezone);
    currentCityState = { ...city };

    displayCurrentWeather(weatherData, currentCityState);
    displayHourlyForecast(weatherData);
    displayDailyForecast(weatherData);

    if (elements.lastUpdatedText) {
      const now = new Date();
      elements.lastUpdatedText.textContent = `Updated: ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
  } catch (error) {
    showError(error.message || "Failed to retrieve weather data. Please verify your connection.");
  } finally {
    hideLoading();
  }
}

async function handleSearch(e) {
  if (e) {
    e.preventDefault();
  }

  const query = elements.searchInput ? elements.searchInput.value.trim() : "";

  if (!query) {
    showError("Please enter a city name to search.");
    if (elements.searchInput) {
      elements.searchInput.focus();
    }
    return;
  }

  showLoading();

  try {
    const results = await window.searchCity(query);
    const selectedCity = results[0];

    if (elements.searchInput) {
      elements.searchInput.value = `${selectedCity.name}, ${selectedCity.country || selectedCity.admin1}`;
    }

    const weatherData = await window.fetchWeather(selectedCity.latitude, selectedCity.longitude, selectedCity.timezone);
    currentCityState = { ...selectedCity };

    displayCurrentWeather(weatherData, currentCityState);
    displayHourlyForecast(weatherData);
    displayDailyForecast(weatherData);

    if (elements.lastUpdatedText) {
      const now = new Date();
      elements.lastUpdatedText.textContent = `Updated: ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
  } catch (error) {
    showError(error.message || "Failed to find city or retrieve weather data.");
  } finally {
    hideLoading();
  }
}

function renderPopularCities() {
  if (!elements.popularCitiesContainer) return;

  const chipsHtml = window.POPULAR_CITIES.map((city) => {
    return `
      <button type="button" class="btn btn-sm btn-outline-glass rounded-pill popular-city-chip px-3 py-1 me-2 mb-2" data-city='${JSON.stringify(city)}'>
        <i class="bi bi-geo-alt-fill me-1 small"></i>${city.name}
      </button>
    `;
  }).join("");

  elements.popularCitiesContainer.innerHTML = chipsHtml;

  elements.popularCitiesContainer.querySelectorAll(".popular-city-chip").forEach((button) => {
    button.addEventListener("click", () => {
      try {
        const cityData = JSON.parse(button.getAttribute("data-city"));
        if (elements.searchInput) {
          elements.searchInput.value = `${cityData.name}, ${cityData.country}`;
        }
        loadWeatherForCity(cityData);
      } catch (err) {
        showError("Failed to select city.");
      }
    });
  });
}

function setupEventListeners() {
  if (elements.searchForm) {
    elements.searchForm.addEventListener("submit", handleSearch);
  }

  if (elements.searchBtn) {
    elements.searchBtn.addEventListener("click", handleSearch);
  }

  if (elements.searchInput) {
    elements.searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        handleSearch(e);
      }
    });
  }

  if (elements.refreshBtn) {
    elements.refreshBtn.addEventListener("click", () => {
      loadWeatherForCity(currentCityState);
    });
  }

  if (elements.errorDismiss) {
    elements.errorDismiss.addEventListener("click", hideError);
  }
}

function initializeApp() {
  initElements();
  setupEventListeners();
  renderPopularCities();
  loadWeatherForCity(window.DEFAULT_CITY);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}

window.handleSearch = handleSearch;
window.loadWeatherForCity = loadWeatherForCity;
window.displayCurrentWeather = displayCurrentWeather;
window.displayHourlyForecast = displayHourlyForecast;
window.displayDailyForecast = displayDailyForecast;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.showError = showError;
window.hideError = hideError;
