async function searchCity(cityName) {
  if (!cityName || !cityName.trim()) {
    throw new Error("Please enter a city name to search.");
  }

  const queryParams = new URLSearchParams({
    name: cityName.trim(),
    count: "5",
    language: "en",
    format: "json"
  });

  const endpoint = `${window.GEO_API}?${queryParams.toString()}`;

  const response = await fetch(endpoint);

  if (!response.ok) {
    throw new Error(`Location search failed with status: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  if (!data || !Array.isArray(data.results) || data.results.length === 0) {
    throw new Error(`No locations found for "${cityName.trim()}". Please check your spelling and try again.`);
  }

  return data.results.map((result) => ({
    id: result.id,
    name: result.name,
    country: result.country || "",
    countryCode: result.country_code || "",
    admin1: result.admin1 || "",
    latitude: result.latitude,
    longitude: result.longitude,
    timezone: result.timezone || "auto",
    elevation: result.elevation
  }));
}

async function fetchWeather(latitude, longitude, timezone = "auto") {
  if (typeof latitude !== "number" || typeof longitude !== "number") {
    throw new Error("Valid geographic coordinates (latitude and longitude) are required.");
  }

  const queryParams = new URLSearchParams({
    latitude: latitude.toString(),
    longitude: longitude.toString(),
    current: [
      "temperature_2m",
      "relative_humidity_2m",
      "apparent_temperature",
      "is_day",
      "precipitation",
      "weather_code",
      "cloud_cover",
      "pressure_msl",
      "wind_speed_10m",
      "wind_direction_10m"
    ].join(","),
    hourly: [
      "temperature_2m",
      "precipitation_probability",
      "weather_code"
    ].join(","),
    daily: [
      "weather_code",
      "temperature_2m_max",
      "temperature_2m_min",
      "sunrise",
      "sunset"
    ].join(","),
    timezone: timezone || "auto",
    forecast_days: "5"
  });

  const endpoint = `${window.WEATHER_API}?${queryParams.toString()}`;

  const response = await fetch(endpoint);

  if (!response.ok) {
    throw new Error(`Weather forecast request failed with status: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  if (!data || !data.current || !data.hourly || !data.daily) {
    throw new Error("Received incomplete or malformed weather data from the weather service.");
  }

  return data;
}

function getWeatherDescription(code) {
  const codeNumber = Number(code);
  return window.WMO_CODES[codeNumber]?.description || "Variable Conditions";
}

function getWeatherIcon(code, isDay = 1) {
  const codeNumber = Number(code);
  const info = window.WMO_CODES[codeNumber];

  if (!info) {
    return isDay ? "bi-cloud-sun" : "bi-cloud-moon";
  }

  return isDay ? info.dayIcon : info.nightIcon;
}

function getWeatherColor(code) {
  const codeNumber = Number(code);
  return window.WMO_CODES[codeNumber]?.color || "#4299e1";
}

function getWindDirection(degrees) {
  const directions = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  const normalized = Math.round(degrees / 22.5) % 16;
  return directions[normalized] || "N";
}

window.searchCity = searchCity;
window.fetchWeather = fetchWeather;
window.getWeatherDescription = getWeatherDescription;
window.getWeatherIcon = getWeatherIcon;
window.getWeatherColor = getWeatherColor;
window.getWindDirection = getWindDirection;
