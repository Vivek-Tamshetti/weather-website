const GEO_API = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_API = "https://api.open-meteo.com/v1/forecast";

const DEFAULT_CITY = {
  name: "Mumbai",
  country: "India",
  admin1: "Maharashtra",
  latitude: 19.076,
  longitude: 72.8777,
  timezone: "Asia/Kolkata"
};

const POPULAR_CITIES = [
  { name: "London", country: "United Kingdom", latitude: 51.5085, longitude: -0.1257 },
  { name: "New York", country: "United States", latitude: 40.7128, longitude: -74.006 },
  { name: "Tokyo", country: "Japan", latitude: 35.6895, longitude: 139.6917 },
  { name: "Paris", country: "France", latitude: 48.8566, longitude: 2.3522 },
  { name: "Sydney", country: "Australia", latitude: -33.8688, longitude: 151.2093 }
];

const WMO_CODES = {
  0: {
    description: "Clear Sky",
    dayIcon: "bi-sun-fill",
    nightIcon: "bi-moon-stars-fill",
    color: "#f6ad55"
  },
  1: {
    description: "Mainly Clear",
    dayIcon: "bi-cloud-sun-fill",
    nightIcon: "bi-cloud-moon-fill",
    color: "#f6e05e"
  },
  2: {
    description: "Partly Cloudy",
    dayIcon: "bi-cloud-sun",
    nightIcon: "bi-cloud-moon",
    color: "#cbd5e0"
  },
  3: {
    description: "Overcast",
    dayIcon: "bi-clouds-fill",
    nightIcon: "bi-clouds-fill",
    color: "#a0aec0"
  },
  45: {
    description: "Foggy",
    dayIcon: "bi-cloud-fog2-fill",
    nightIcon: "bi-cloud-fog2-fill",
    color: "#a0aec0"
  },
  48: {
    description: "Depositing Rime Fog",
    dayIcon: "bi-cloud-fog2-fill",
    nightIcon: "bi-cloud-fog2-fill",
    color: "#a0aec0"
  },
  51: {
    description: "Light Drizzle",
    dayIcon: "bi-cloud-drizzle-fill",
    nightIcon: "bi-cloud-drizzle-fill",
    color: "#63b3ed"
  },
  53: {
    description: "Moderate Drizzle",
    dayIcon: "bi-cloud-drizzle-fill",
    nightIcon: "bi-cloud-drizzle-fill",
    color: "#4299e1"
  },
  55: {
    description: "Dense Drizzle",
    dayIcon: "bi-cloud-drizzle-fill",
    nightIcon: "bi-cloud-drizzle-fill",
    color: "#3182ce"
  },
  56: {
    description: "Light Freezing Drizzle",
    dayIcon: "bi-cloud-sleet-fill",
    nightIcon: "bi-cloud-sleet-fill",
    color: "#81e6d9"
  },
  57: {
    description: "Dense Freezing Drizzle",
    dayIcon: "bi-cloud-sleet-fill",
    nightIcon: "bi-cloud-sleet-fill",
    color: "#4fd1c5"
  },
  61: {
    description: "Slight Rain",
    dayIcon: "bi-cloud-rain-fill",
    nightIcon: "bi-cloud-rain-fill",
    color: "#63b3ed"
  },
  63: {
    description: "Moderate Rain",
    dayIcon: "bi-cloud-rain-fill",
    nightIcon: "bi-cloud-rain-fill",
    color: "#3182ce"
  },
  65: {
    description: "Heavy Rain",
    dayIcon: "bi-cloud-rain-heavy-fill",
    nightIcon: "bi-cloud-rain-heavy-fill",
    color: "#2b6cb0"
  },
  66: {
    description: "Light Freezing Rain",
    dayIcon: "bi-cloud-sleet-fill",
    nightIcon: "bi-cloud-sleet-fill",
    color: "#81e6d9"
  },
  67: {
    description: "Heavy Freezing Rain",
    dayIcon: "bi-cloud-sleet-fill",
    nightIcon: "bi-cloud-sleet-fill",
    color: "#38b2ac"
  },
  71: {
    description: "Slight Snowfall",
    dayIcon: "bi-cloud-snow-fill",
    nightIcon: "bi-cloud-snow-fill",
    color: "#e2e8f0"
  },
  73: {
    description: "Moderate Snowfall",
    dayIcon: "bi-cloud-snow-fill",
    nightIcon: "bi-cloud-snow-fill",
    color: "#edf2f7"
  },
  75: {
    description: "Heavy Snowfall",
    dayIcon: "bi-snow",
    nightIcon: "bi-snow",
    color: "#ffffff"
  },
  77: {
    description: "Snow Grains",
    dayIcon: "bi-snow2",
    nightIcon: "bi-snow2",
    color: "#edf2f7"
  },
  80: {
    description: "Slight Rain Showers",
    dayIcon: "bi-cloud-rain-heavy-fill",
    nightIcon: "bi-cloud-rain-heavy-fill",
    color: "#4299e1"
  },
  81: {
    description: "Moderate Rain Showers",
    dayIcon: "bi-cloud-rain-heavy-fill",
    nightIcon: "bi-cloud-rain-heavy-fill",
    color: "#3182ce"
  },
  82: {
    description: "Violent Rain Showers",
    dayIcon: "bi-cloud-rain-heavy-fill",
    nightIcon: "bi-cloud-rain-heavy-fill",
    color: "#2b6cb0"
  },
  85: {
    description: "Slight Snow Showers",
    dayIcon: "bi-cloud-snow-fill",
    nightIcon: "bi-cloud-snow-fill",
    color: "#e2e8f0"
  },
  86: {
    description: "Heavy Snow Showers",
    dayIcon: "bi-cloud-snow-fill",
    nightIcon: "bi-cloud-snow-fill",
    color: "#ffffff"
  },
  95: {
    description: "Thunderstorm",
    dayIcon: "bi-cloud-lightning-fill",
    nightIcon: "bi-cloud-lightning-fill",
    color: "#ecc94b"
  },
  96: {
    description: "Thunderstorm with Hail",
    dayIcon: "bi-cloud-lightning-rain-fill",
    nightIcon: "bi-cloud-lightning-rain-fill",
    color: "#ecc94b"
  },
  99: {
    description: "Severe Thunderstorm with Hail",
    dayIcon: "bi-cloud-lightning-rain-fill",
    nightIcon: "bi-cloud-lightning-rain-fill",
    color: "#d69e2e"
  }
};

window.GEO_API = GEO_API;
window.WEATHER_API = WEATHER_API;
window.DEFAULT_CITY = DEFAULT_CITY;
window.POPULAR_CITIES = POPULAR_CITIES;
window.WMO_CODES = WMO_CODES;
